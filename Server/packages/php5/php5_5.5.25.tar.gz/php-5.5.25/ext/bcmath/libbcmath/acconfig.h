/* PACKAGE name */
#undef PACKAGE

/* Package VERSION number */
#undef VERSION

/* Define to `size_t' if <sys/types.h> and <stddef.h> don't define.  */
#undef ptrdiff_t

