#!/bin/sh
exec g++-4.6 -m32 "$@"
