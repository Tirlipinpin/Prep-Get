#!/bin/sh
exec gcc-4.6 -m32 "$@"
