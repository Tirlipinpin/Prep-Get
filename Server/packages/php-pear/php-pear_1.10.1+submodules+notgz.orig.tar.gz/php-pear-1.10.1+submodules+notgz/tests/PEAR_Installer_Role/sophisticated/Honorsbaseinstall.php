<?php
class PEAR_Installer_Role_Honorsbaseinstall extends PEAR_Installer_Role_Common{}
